package com.example.myappzuulgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyappZuulGatewayApplicationTests {

    @Test
    void contextLoads() {
    }

}
