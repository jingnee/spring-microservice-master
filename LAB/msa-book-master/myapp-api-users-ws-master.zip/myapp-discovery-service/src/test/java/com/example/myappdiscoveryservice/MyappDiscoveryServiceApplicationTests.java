package com.example.myappdiscoveryservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyappDiscoveryServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
